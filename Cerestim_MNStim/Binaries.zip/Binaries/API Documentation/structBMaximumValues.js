var structBMaximumValues =
[
    [ "amplitude", "structBMaximumValues.html#ab34fb354f8703e556bd97d92b551a4e9", null ],
    [ "frequency", "structBMaximumValues.html#a52991657866650aa21f85b97e7d9168c", null ],
    [ "phaseCharge", "structBMaximumValues.html#ad283b266c6f959c6143bae9563daccec", null ],
    [ "voltage", "structBMaximumValues_a15825c1df6f5f1ea55fb0455c343e3fb.html#a15825c1df6f5f1ea55fb0455c343e3fb", null ]
];