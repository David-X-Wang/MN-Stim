var structBElectrodeChannelMap =
[
    [ "bankA", "structBElectrodeChannelMap.html#ab36e7b552f634a5d40bed6456b6e29e0", null ],
    [ "bankB", "structBElectrodeChannelMap.html#a9d565b33502a177539c251de88f315b1", null ],
    [ "bankC", "structBElectrodeChannelMap.html#ac196c29e170ba8ebb761face1897de4b", null ]
];