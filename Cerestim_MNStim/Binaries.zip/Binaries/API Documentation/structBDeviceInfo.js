var structBDeviceInfo =
[
    [ "mainboardVersion", "structBDeviceInfo.html#adb5bed97f7b20d9524a69addc51f93e3", null ],
    [ "moduleStatus", "structBDeviceInfo.html#a8e9915f7f52ecf6d948703e026760b38", null ],
    [ "moduleVersion", "structBDeviceInfo.html#aed8cee6e58eafb31583f5db5c6686058", null ],
    [ "protocolVersion", "structBDeviceInfo.html#aecaf0a8ef2a003d7bbb829470f41b136", null ],
    [ "serialNo", "structBDeviceInfo.html#a0494c2572aeced1777d41315b899fa7f", null ]
];