var structBStimulusConfiguration =
[
    [ "amp1", "structBStimulusConfiguration.html#a3a3dad430ed3bd063d1ebc464172e773", null ],
    [ "amp2", "structBStimulusConfiguration.html#a65c3ed923a0a5a461592750aa3f99cc6", null ],
    [ "anodicFirst", "structBStimulusConfiguration.html#a5363133af9d12788873014d09eccfa62", null ],
    [ "frequency", "structBStimulusConfiguration.html#a52991657866650aa21f85b97e7d9168c", null ],
    [ "interphase", "structBStimulusConfiguration.html#a694b47ca0803394d2fc2fcbb8c4c0d67", null ],
    [ "pulses", "structBStimulusConfiguration.html#af90d51c4b1889f81a14189ea9f4977be", null ],
    [ "width1", "structBStimulusConfiguration.html#a6dc4d691a591e7298f8ff1bff667f98a", null ],
    [ "width2", "structBStimulusConfiguration.html#af28c8d91078fbc4a8e56888f6a9a93a7", null ]
];