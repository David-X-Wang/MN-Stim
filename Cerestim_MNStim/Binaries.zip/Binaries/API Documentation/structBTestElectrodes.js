var structBTestElectrodes =
[
    [ "electrodes", "structBTestElectrodes.html#a430771a15d8efcf53f724d0de32fafbb", null ],
    [ "impedance", "structBTestElectrodes.html#ae04cb6654e9c940c4262e59451b8d6eb", null ]
];