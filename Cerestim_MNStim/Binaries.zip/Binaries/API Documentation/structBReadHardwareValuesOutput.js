var structBReadHardwareValuesOutput =
[
    [ "amp", "structBReadHardwareValuesOutput.html#ae0a016308429f98c504bea48f2717506", null ],
    [ "charge", "structBReadHardwareValuesOutput.html#a0978fc9c5c90c694895437b21147d7de", null ],
    [ "interphase", "structBReadHardwareValuesOutput.html#a694b47ca0803394d2fc2fcbb8c4c0d67", null ],
    [ "maxCompVoltage", "structBReadHardwareValuesOutput_af39ce53a5a5bc80928de7c47ac998bba.html#af39ce53a5a5bc80928de7c47ac998bba", null ],
    [ "maxFreq", "structBReadHardwareValuesOutput.html#a0bee64a03ebfa31eb5e910d807ebbeb7", null ],
    [ "minCompVoltage", "structBReadHardwareValuesOutput_addc1e335f3d731a89968ddacc79d77a0.html#addc1e335f3d731a89968ddacc79d77a0", null ],
    [ "minFreq", "structBReadHardwareValuesOutput.html#a957b8ba8b883649730f66d5f3968b69a", null ],
    [ "modules", "structBReadHardwareValuesOutput.html#a5214500962008733b469430ed61e865a", null ],
    [ "width", "structBReadHardwareValuesOutput.html#a14210216287c046c2394bf374c22c1c7", null ]
];