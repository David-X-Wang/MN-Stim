var structBUsbParams =
[
    [ "pid", "structBUsbParams.html#a448af1f0bbdd31d81c25c553685d9cb4", null ],
    [ "size", "structBUsbParams.html#a6d4bac4be8d2f0ee400eb63ac2204aac", null ],
    [ "timeout", "structBUsbParams.html#a89d0e080863509070eee6b8c7a2333c1", null ],
    [ "vid", "structBUsbParams.html#a34b81b9676b9f1ec8a755d6d374d1274", null ]
];