var structBGroupStimulus =
[
    [ "electrode", "structBGroupStimulus.html#ac9942a0d1cca32776754dd38b097bcec", null ],
    [ "pattern", "structBGroupStimulus.html#a7e96c98f7cb78f4929658360da943282", null ]
];