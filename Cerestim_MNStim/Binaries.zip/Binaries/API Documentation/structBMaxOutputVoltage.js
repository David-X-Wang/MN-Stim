var structBMaxOutputVoltage =
[
    [ "miliVolts", "structBMaxOutputVoltage.html#ab687b704638d0a2640d238f44ff149cc", null ]
];