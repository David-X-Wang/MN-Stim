var annotated_dup =
[
    [ "BDeviceInfo", "structBDeviceInfo.html", "structBDeviceInfo" ],
    [ "BElectrodeChannelMap", "structBElectrodeChannelMap.html", "structBElectrodeChannelMap" ],
    [ "BGroupStimulus", "structBGroupStimulus.html", "structBGroupStimulus" ],
    [ "BMaximumValues", "structBMaximumValues.html", "structBMaximumValues" ],
    [ "BMaxOutputVoltage", "structBMaxOutputVoltage.html", "structBMaxOutputVoltage" ],
    [ "BOutputMeasurement", "structBOutputMeasurement.html", "structBOutputMeasurement" ],
    [ "BReadEEpromOutput", "structBReadEEpromOutput.html", "structBReadEEpromOutput" ],
    [ "BReadHardwareValuesOutput", "structBReadHardwareValuesOutput.html", "structBReadHardwareValuesOutput" ],
    [ "BSequenceStatus", "structBSequenceStatus.html", "structBSequenceStatus" ],
    [ "BStimulator", "classBStimulator.html", "classBStimulator" ],
    [ "BStimulusConfiguration", "structBStimulusConfiguration.html", "structBStimulusConfiguration" ],
    [ "BTestElectrodes", "structBTestElectrodes.html", "structBTestElectrodes" ],
    [ "BTestModules", "structBTestModules.html", "structBTestModules" ],
    [ "BUsbParams", "structBUsbParams.html", "structBUsbParams" ],
    [ "BVersion", "structBVersion.html", "structBVersion" ]
];