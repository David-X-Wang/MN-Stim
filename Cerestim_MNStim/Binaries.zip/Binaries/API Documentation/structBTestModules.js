var structBTestModules =
[
    [ "modulesMV", "structBTestModules.html#a2a97f3bf2c8ef53bbcf6cff5fbfba963", null ],
    [ "modulesStatus", "structBTestModules_ac54563fe6381724cfaa047004af7b156.html#ac54563fe6381724cfaa047004af7b156", null ]
];