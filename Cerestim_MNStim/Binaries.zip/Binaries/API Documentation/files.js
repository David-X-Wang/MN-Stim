var files =
[
    [ "BStimulator.cpp", "BStimulator_8cpp.html", null ],
    [ "BStimulator.h", "BStimulator_8h.html", "BStimulator_8h" ]
];