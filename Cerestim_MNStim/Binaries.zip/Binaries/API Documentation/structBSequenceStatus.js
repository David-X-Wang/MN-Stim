var structBSequenceStatus =
[
    [ "status", "structBSequenceStatus.html#ac4f6d5d1544a8d2c1309479ffe1b61ab", null ]
];