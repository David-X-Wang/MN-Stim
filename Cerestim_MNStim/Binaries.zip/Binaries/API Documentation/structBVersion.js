var structBVersion =
[
    [ "beta", "structBVersion.html#a53b893f6b1a2cbcebfdc57ba753d27ee", null ],
    [ "major", "structBVersion.html#aecd30f62be9496c3478be7be07620023", null ],
    [ "minor", "structBVersion.html#a775bf6899fe42c57201f6f5f3b99cb0a", null ],
    [ "release", "structBVersion.html#af67a54cc5f726c5f78f9926cdeef6e0d", null ]
];