var searchData=
[
  ['impedance',['impedance',['../structBTestElectrodes.html#ae04cb6654e9c940c4262e59451b8d6eb',1,'BTestElectrodes']]],
  ['interphase',['interphase',['../structBStimulusConfiguration.html#a694b47ca0803394d2fc2fcbb8c4c0d67',1,'BStimulusConfiguration::interphase()'],['../structBReadHardwareValuesOutput.html#a694b47ca0803394d2fc2fcbb8c4c0d67',1,'BReadHardwareValuesOutput::interphase()']]]
];
