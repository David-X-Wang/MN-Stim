var searchData=
[
  ['bcallback',['BCallback',['../BStimulator_8h_aee4173250ec211760ebeaeb4f1856142.html#aee4173250ec211760ebeaeb4f1856142',1,'BStimulator.h']]],
  ['bstimhandle',['BStimHandle',['../BStimulator_8h.html#a0bd236c7a759e1a569dd773e25d286fb',1,'BStimulator.h']]]
];
