var searchData=
[
  ['charge',['charge',['../structBReadHardwareValuesOutput.html#a0978fc9c5c90c694895437b21147d7de',1,'BReadHardwareValuesOutput']]]
];
