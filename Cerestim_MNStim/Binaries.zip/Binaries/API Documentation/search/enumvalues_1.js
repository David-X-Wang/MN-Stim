var searchData=
[
  ['invalid_5fstim',['INVALID_STIM',['../BStimulator_8h_a2d21e704d4462280b7221d5a14141211.html#a2d21e704d4462280b7221d5a14141211a63490e2bdb649b57f40e935358c605df',1,'BStimulator.h']]]
];
