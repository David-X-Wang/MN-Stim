var searchData=
[
  ['vid',['vid',['../structBUsbParams.html#a34b81b9676b9f1ec8a755d6d374d1274',1,'BUsbParams']]],
  ['voltage',['voltage',['../structBMaximumValues_a15825c1df6f5f1ea55fb0455c343e3fb.html#a15825c1df6f5f1ea55fb0455c343e3fb',1,'BMaximumValues']]]
];
