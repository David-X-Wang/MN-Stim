var searchData=
[
  ['getinterface',['getInterface',['../classBStimulator_a3589b9470d6b92a368bcbdec1995b88b.html#a3589b9470d6b92a368bcbdec1995b88b',1,'BStimulator']]],
  ['getmaxhardcharge',['getMaxHardCharge',['../classBStimulator_ac6f323c668722c21250003a874c657da.html#ac6f323c668722c21250003a874c657da',1,'BStimulator']]],
  ['getmaxhardfrequency',['getMaxHardFrequency',['../classBStimulator_acaab5eee23af7352b99db02b33926bd6.html#acaab5eee23af7352b99db02b33926bd6',1,'BStimulator']]],
  ['getmaxhardinterphase',['getMaxHardInterphase',['../classBStimulator_a90c974ed7822f30686d0825838230c15.html#a90c974ed7822f30686d0825838230c15',1,'BStimulator']]],
  ['getmaxhardwidth',['getMaxHardWidth',['../classBStimulator_a5fdeadf2e70b7b312b35ba0e818eb570.html#a5fdeadf2e70b7b312b35ba0e818eb570',1,'BStimulator']]],
  ['getminhardfrequency',['getMinHardFrequency',['../classBStimulator_adfe0ab937ecccb148e111ff62a4d4111.html#adfe0ab937ecccb148e111ff62a4d4111',1,'BStimulator']]],
  ['getminmaxamplitude',['getMinMaxAmplitude',['../classBStimulator_aabfc132db83ae190a4da29a9bf123a5f.html#aabfc132db83ae190a4da29a9bf123a5f',1,'BStimulator']]],
  ['getmodulefirmwareversion',['getModuleFirmwareVersion',['../classBStimulator_afb972caa0062d398d5e5eebef2f44aa1.html#afb972caa0062d398d5e5eebef2f44aa1',1,'BStimulator']]],
  ['getmodulestatus',['getModuleStatus',['../classBStimulator_aa9b77a42c00f008e188c85eccceb3c17.html#aa9b77a42c00f008e188c85eccceb3c17',1,'BStimulator']]],
  ['getmotherboardfirmwareversion',['getMotherboardFirmwareVersion',['../classBStimulator_af2facd5b928d735cc9aeef3e4e70d2d7.html#af2facd5b928d735cc9aeef3e4e70d2d7',1,'BStimulator']]],
  ['getnumbermodules',['getNumberModules',['../classBStimulator_ac5d45bfedfe32096ec98909abdce1e2f.html#ac5d45bfedfe32096ec98909abdce1e2f',1,'BStimulator']]],
  ['getprotocolversion',['getProtocolVersion',['../classBStimulator_ac0b06c85dfec5c78817c6d74ac103e1a.html#ac0b06c85dfec5c78817c6d74ac103e1a',1,'BStimulator']]],
  ['getserialnumber',['getSerialNumber',['../classBStimulator_a2a2988265f0d1bac1f67c5945ad7e89b.html#a2a2988265f0d1bac1f67c5945ad7e89b',1,'BStimulator']]],
  ['getusbaddress',['getUSBAddress',['../classBStimulator_a7f19979107253ec22798e0cb6297371d.html#a7f19979107253ec22798e0cb6297371d',1,'BStimulator']]],
  ['groupstimulus',['groupStimulus',['../classBStimulator_ad8cc4c6f636cbb7104d6ebb7ef5e0c8e.html#ad8cc4c6f636cbb7104d6ebb7ef5e0c8e',1,'BStimulator']]]
];
