var searchData=
[
  ['uint16',['UINT16',['../BStimulator_8h.html#ad074b5a138cda7852cae530f9c18dcd4',1,'BStimulator.h']]],
  ['uint32',['UINT32',['../BStimulator_8h.html#a4b15b1387a081707069b73235934f2da',1,'BStimulator.h']]],
  ['uint8',['UINT8',['../BStimulator_8h.html#a22cf2017d4f8abc9284fab02f06ca8d5',1,'BStimulator.h']]],
  ['updateelectrodechannelmap',['updateElectrodeChannelMap',['../classBStimulator_a734b8423b6f73230095497c17bb5dafd.html#a734b8423b6f73230095497c17bb5dafd',1,'BStimulator']]]
];
