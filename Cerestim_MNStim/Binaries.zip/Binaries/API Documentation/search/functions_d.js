var searchData=
[
  ['updateelectrodechannelmap',['updateElectrodeChannelMap',['../classBStimulator_a734b8423b6f73230095497c17bb5dafd.html#a734b8423b6f73230095497c17bb5dafd',1,'BStimulator']]]
];
