var searchData=
[
  ['impedance',['impedance',['../structBTestElectrodes.html#ae04cb6654e9c940c4262e59451b8d6eb',1,'BTestElectrodes']]],
  ['int16',['INT16',['../BStimulator_8h.html#aedb3ed11796a8871bd9c1703ad3d00e9',1,'BStimulator.h']]],
  ['int32',['INT32',['../BStimulator_8h.html#a0ec8ef3166e60db3a3ed3165e6ff19fa',1,'BStimulator.h']]],
  ['int8',['INT8',['../BStimulator_8h.html#aae644b6193d1cfd76f19e5f88a2da176',1,'BStimulator.h']]],
  ['interphase',['interphase',['../structBStimulusConfiguration.html#a694b47ca0803394d2fc2fcbb8c4c0d67',1,'BStimulusConfiguration::interphase()'],['../structBReadHardwareValuesOutput.html#a694b47ca0803394d2fc2fcbb8c4c0d67',1,'BReadHardwareValuesOutput::interphase()']]],
  ['invalid_5fstim',['INVALID_STIM',['../BStimulator_8h_a2d21e704d4462280b7221d5a14141211.html#a2d21e704d4462280b7221d5a14141211a63490e2bdb649b57f40e935358c605df',1,'BStimulator.h']]],
  ['isconnected',['isConnected',['../classBStimulator_aaf030ee81e96a439df5d2456cf313b1b.html#aaf030ee81e96a439df5d2456cf313b1b',1,'BStimulator']]],
  ['isdevicelocked',['isDeviceLocked',['../classBStimulator_a5a526aaabf898be32faf59c57a982830.html#a5a526aaabf898be32faf59c57a982830',1,'BStimulator']]],
  ['issafetydisabled',['isSafetyDisabled',['../classBStimulator_ad8077ba2ff480a6b30042bbeb131b3ea.html#ad8077ba2ff480a6b30042bbeb131b3ea',1,'BStimulator']]]
];
