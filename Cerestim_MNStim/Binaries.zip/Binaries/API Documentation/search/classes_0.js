var searchData=
[
  ['bdeviceinfo',['BDeviceInfo',['../structBDeviceInfo.html',1,'']]],
  ['belectrodechannelmap',['BElectrodeChannelMap',['../structBElectrodeChannelMap.html',1,'']]],
  ['bgroupstimulus',['BGroupStimulus',['../structBGroupStimulus.html',1,'']]],
  ['bmaximumvalues',['BMaximumValues',['../structBMaximumValues.html',1,'']]],
  ['bmaxoutputvoltage',['BMaxOutputVoltage',['../structBMaxOutputVoltage.html',1,'']]],
  ['boutputmeasurement',['BOutputMeasurement',['../structBOutputMeasurement.html',1,'']]],
  ['breadeepromoutput',['BReadEEpromOutput',['../structBReadEEpromOutput.html',1,'']]],
  ['breadhardwarevaluesoutput',['BReadHardwareValuesOutput',['../structBReadHardwareValuesOutput.html',1,'']]],
  ['bsequencestatus',['BSequenceStatus',['../structBSequenceStatus.html',1,'']]],
  ['bstimulator',['BStimulator',['../classBStimulator.html',1,'']]],
  ['bstimulusconfiguration',['BStimulusConfiguration',['../structBStimulusConfiguration.html',1,'']]],
  ['btestelectrodes',['BTestElectrodes',['../structBTestElectrodes.html',1,'']]],
  ['btestmodules',['BTestModules',['../structBTestModules.html',1,'']]],
  ['busbparams',['BUsbParams',['../structBUsbParams.html',1,'']]],
  ['bversion',['BVersion',['../structBVersion.html',1,'']]]
];
