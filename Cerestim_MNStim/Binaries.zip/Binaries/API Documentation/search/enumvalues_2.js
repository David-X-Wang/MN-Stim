var searchData=
[
  ['macro_5fstim',['MACRO_STIM',['../BStimulator_8h_a2d21e704d4462280b7221d5a14141211.html#a2d21e704d4462280b7221d5a14141211aa72badc0207c7c50c103109a99804887',1,'BStimulator.h']]],
  ['micro_5fstim',['MICRO_STIM',['../BStimulator_8h_a2d21e704d4462280b7221d5a14141211.html#a2d21e704d4462280b7221d5a14141211af8c4d0f901bc3ae7c6cf3c092e93eddf',1,'BStimulator.h']]]
];
