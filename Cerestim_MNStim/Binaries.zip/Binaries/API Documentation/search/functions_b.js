var searchData=
[
  ['scanfordevices',['scanForDevices',['../classBStimulator_aa65c1f82d600688ea522fa1e3c1181b8.html#aa65c1f82d600688ea522fa1e3c1181b8',1,'BStimulator']]],
  ['setdevice',['setDevice',['../classBStimulator_ab4edd55bfb4e0e0ee4b45ea118d99764.html#ab4edd55bfb4e0e0ee4b45ea118d99764',1,'BStimulator']]],
  ['stimulusmaxvalues',['stimulusMaxValues',['../classBStimulator_ac92da95a7fd8d8b08096df4a47ae61cc.html#ac92da95a7fd8d8b08096df4a47ae61cc',1,'BStimulator']]],
  ['stop',['stop',['../classBStimulator_afbeec22f2971afa7ec3a05e6297ccb16.html#afbeec22f2971afa7ec3a05e6297ccb16',1,'BStimulator']]],
  ['stoptriggerstimulus',['stopTriggerStimulus',['../classBStimulator_a8169332bb3018a4ca97818e1f5bfd181.html#a8169332bb3018a4ca97818e1f5bfd181',1,'BStimulator']]]
];
