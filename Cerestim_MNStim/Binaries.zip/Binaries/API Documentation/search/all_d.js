var searchData=
[
  ['scanfordevices',['scanForDevices',['../classBStimulator_aa65c1f82d600688ea522fa1e3c1181b8.html#aa65c1f82d600688ea522fa1e3c1181b8',1,'BStimulator']]],
  ['serialno',['serialNo',['../structBDeviceInfo.html#a0494c2572aeced1777d41315b899fa7f',1,'BDeviceInfo']]],
  ['setdevice',['setDevice',['../classBStimulator_ab4edd55bfb4e0e0ee4b45ea118d99764.html#ab4edd55bfb4e0e0ee4b45ea118d99764',1,'BStimulator']]],
  ['size',['size',['../structBUsbParams.html#a6d4bac4be8d2f0ee400eb63ac2204aac',1,'BUsbParams']]],
  ['status',['status',['../structBSequenceStatus.html#ac4f6d5d1544a8d2c1309479ffe1b61ab',1,'BSequenceStatus']]],
  ['stimulusmaxvalues',['stimulusMaxValues',['../classBStimulator_ac92da95a7fd8d8b08096df4a47ae61cc.html#ac92da95a7fd8d8b08096df4a47ae61cc',1,'BStimulator']]],
  ['stop',['stop',['../classBStimulator_afbeec22f2971afa7ec3a05e6297ccb16.html#afbeec22f2971afa7ec3a05e6297ccb16',1,'BStimulator']]],
  ['stoptriggerstimulus',['stopTriggerStimulus',['../classBStimulator_a8169332bb3018a4ca97818e1f5bfd181.html#a8169332bb3018a4ca97818e1f5bfd181',1,'BStimulator']]]
];
