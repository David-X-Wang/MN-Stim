var searchData=
[
  ['pattern',['pattern',['../structBGroupStimulus.html#a7e96c98f7cb78f4929658360da943282',1,'BGroupStimulus']]],
  ['phasecharge',['phaseCharge',['../structBMaximumValues.html#ad283b266c6f959c6143bae9563daccec',1,'BMaximumValues']]],
  ['pid',['pid',['../structBUsbParams.html#a448af1f0bbdd31d81c25c553685d9cb4',1,'BUsbParams']]],
  ['protocolversion',['protocolVersion',['../structBDeviceInfo.html#aecaf0a8ef2a003d7bbb829470f41b136',1,'BDeviceInfo']]],
  ['pulses',['pulses',['../structBStimulusConfiguration.html#af90d51c4b1889f81a14189ea9f4977be',1,'BStimulusConfiguration']]]
];
