var searchData=
[
  ['banka',['bankA',['../structBElectrodeChannelMap.html#ab36e7b552f634a5d40bed6456b6e29e0',1,'BElectrodeChannelMap']]],
  ['bankb',['bankB',['../structBElectrodeChannelMap.html#a9d565b33502a177539c251de88f315b1',1,'BElectrodeChannelMap']]],
  ['bankc',['bankC',['../structBElectrodeChannelMap.html#ac196c29e170ba8ebb761face1897de4b',1,'BElectrodeChannelMap']]],
  ['banksize',['BANKSIZE',['../BStimulator_8h.html#afaeb8a61a03f6402c02c0e7c2862f249',1,'BStimulator.h']]],
  ['beta',['beta',['../structBVersion.html#a53b893f6b1a2cbcebfdc57ba753d27ee',1,'BVersion']]]
];
