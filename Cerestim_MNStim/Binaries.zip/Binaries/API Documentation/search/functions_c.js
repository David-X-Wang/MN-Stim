var searchData=
[
  ['testelectrodes',['testElectrodes',['../classBStimulator_aa95585cda79ff6e7e5eaf38bc6592d3f.html#aa95585cda79ff6e7e5eaf38bc6592d3f',1,'BStimulator']]],
  ['testmodules',['testModules',['../classBStimulator_a21d5b4e27706337653209d4540c33355.html#a21d5b4e27706337653209d4540c33355',1,'BStimulator']]],
  ['triggerstimulus',['triggerStimulus',['../classBStimulator_ae805a41d308b2f51d8a7a0692e3deabd.html#ae805a41d308b2f51d8a7a0692e3deabd',1,'BStimulator']]]
];
