var searchData=
[
  ['frequency',['frequency',['../structBStimulusConfiguration.html#a52991657866650aa21f85b97e7d9168c',1,'BStimulusConfiguration::frequency()'],['../structBMaximumValues.html#a52991657866650aa21f85b97e7d9168c',1,'BMaximumValues::frequency()']]]
];
