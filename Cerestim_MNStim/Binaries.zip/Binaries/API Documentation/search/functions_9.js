var searchData=
[
  ['pause',['pause',['../classBStimulator_a9e0aae33d1343f1342f4a26099139071.html#a9e0aae33d1343f1342f4a26099139071',1,'BStimulator']]],
  ['play',['play',['../classBStimulator_a1dcd68711682802e4203526b87595bf1.html#a1dcd68711682802e4203526b87595bf1',1,'BStimulator']]]
];
