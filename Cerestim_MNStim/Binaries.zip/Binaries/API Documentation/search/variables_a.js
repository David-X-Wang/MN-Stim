var searchData=
[
  ['serialno',['serialNo',['../structBDeviceInfo.html#a0494c2572aeced1777d41315b899fa7f',1,'BDeviceInfo']]],
  ['size',['size',['../structBUsbParams.html#a6d4bac4be8d2f0ee400eb63ac2204aac',1,'BUsbParams']]],
  ['status',['status',['../structBSequenceStatus.html#ac4f6d5d1544a8d2c1309479ffe1b61ab',1,'BSequenceStatus']]]
];
