var searchData=
[
  ['isconnected',['isConnected',['../classBStimulator_aaf030ee81e96a439df5d2456cf313b1b.html#aaf030ee81e96a439df5d2456cf313b1b',1,'BStimulator']]],
  ['isdevicelocked',['isDeviceLocked',['../classBStimulator_a5a526aaabf898be32faf59c57a982830.html#a5a526aaabf898be32faf59c57a982830',1,'BStimulator']]],
  ['issafetydisabled',['isSafetyDisabled',['../classBStimulator_ad8077ba2ff480a6b30042bbeb131b3ea.html#ad8077ba2ff480a6b30042bbeb131b3ea',1,'BStimulator']]]
];
