var searchData=
[
  ['configurestimuluspattern',['configureStimulusPattern',['../classBStimulator_afa169cc51004ad1ca3816d8cf1b1ea35.html#afa169cc51004ad1ca3816d8cf1b1ea35',1,'BStimulator']]],
  ['connect',['connect',['../classBStimulator_aa1cc9f97404b03500ac95fa55bf32f5e.html#aa1cc9f97404b03500ac95fa55bf32f5e',1,'BStimulator']]]
];
